~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ rotate_pdf ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	A small program to rotate pdf pages.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Notes About the Program ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	This exe was built using pyinstaller. Meaning that Python and all program
	dependencies are built-in. This allows for any pc to run this program
	without needing Python and the necessary libraries already installed.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Links ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	Download the exe and original python program, or view the source code at
	https://github.com/GLukeM-H/rotate_pdf

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Setup ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	If viewing on your G drive via Drive File Stream, all necessary files
	should already be synced locally to your system. You can run this program
	directly from here.

	If viewing on google drive, download the entire rotate_pdf folder. Not just
	the exe! You may move the folder anywhere on your hard drive after that.
	Note that some virus protection software don't like you running exe's that
	aren't in their databases! If you run into this problem, try running the
	program from G drive or even run the original python program which you can
	get from the GitHub address above.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ How to Use (Succinct) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	1.	Run rotate_pdf.exe
	2.	Choose pdf file when prompted
	3.	List pages and indicate any page ranges using hyphens

	You will find a new pdf with the specified pages rotated in the same
	directory as the original.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ How to Use (Verbose) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	1.	Run rotate_pdf.exe from within the rotate_pdf folder. An input
		window will pop up with the text "Which pdf?" followed by a
		pop up file selection GUI.

		If this text does not appear right away, give it a few seconds.
		(Bundled libraries are compressed to save space and are
		decompressed on runtime.) If nothing appears after several
		seconds, make sure all the necessary files are downloaded and
		you are running this exe from within the rotate_pdf folder as
		described in Setup.

		    --------------------------------------------------

	2.	Navigate to the pdf that needs pages rotated and open it. For
		example, navigate to the folder

			G:\My Drive\Current Students\Justin Example\

		Choose the pdf and click "open".

		    --------------------------------------------------

	3.	If the file was successfully opened, you will then be asked which
		pages you would like rotated, and will see the additional prompt:

			List or range of pages to rotate (e.g. 3 4 5 or 3-5)

		Enter a space separated list of pages and/or page ranges that you
		would like rotated. A page listed once will be rotated clockwise by
		90 degrees. A page listed twice will be rotated twice by 90 degrees
		and so on.

		For example, all of the following will rotate the even numbered
		pages from 1-10 clockwise by 90 degrees and odd numbered pages by
		180 degrees while leaving all other pages after page 10 oriented
		the same.

			1 1 2 3 3 4 5 5 6 7 7 8 9 9 10

				or

			1-10 1 3 5 7 9

				or

			1 3 5 7 9 1-5 6-10

				or

			1 3 1-5 7 9 5-10 11 11 11 11

		    --------------------------------------------------

	4.	Press <enter> to close the program.

		Now, look in the original pdf's directory which would be
		G:\My Drive\Current Students\Justin Example\ from step 2. A new pdf
		with the original's file name ending in " - rotated.pdf" should now
		be written to this directory with the specified pages rotated.

		Note that running this program again on the same pdf will overwrite
		the rotated pdf with a new one if in the same location and not
		renamed.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~